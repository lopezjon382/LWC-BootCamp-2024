import { LightningElement } from 'lwc';

export default class DataBindingExpression extends LightningElement {
    greeting = 'World';
}